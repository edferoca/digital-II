#!/usr/bin/env python3
import os
os.system("djtgcfg prog -d Nexys4DDR -i 0 -f ./build/gateware/top.bit")
